_MAJOR = "0"
_MINOR = "1"
_REVISION = "0-unreleased"

VERSION_SHORT = "{0}.{1}".format(_MAJOR, _MINOR)
VERSION = "{0}.{1}.{2}".format(_MAJOR, _MINOR, _REVISION)
